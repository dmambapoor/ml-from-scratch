
class DNN:
    
    def __init__(self):
        pass

    def square(self, x):
        return x * x