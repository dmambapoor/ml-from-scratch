# ml-from-scratch
A project where I code machine learning models using only pandas and numpy.

[![Tests](https://github.com/dmambapoor/ml-from-scratch/actions/workflows/tests.yml/badge.svg)](https://github.com/dmambapoor/ml-from-scratch/actions/workflows/tests.yml)