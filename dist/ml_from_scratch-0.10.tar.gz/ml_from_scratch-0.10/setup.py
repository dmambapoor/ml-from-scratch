# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['deep_learning_from_scratch']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.6.2,<4.0.0', 'numpy>=1.24.1,<2.0.0', 'pandas>=1.5.2,<2.0.0']

setup_kwargs = {
    'name': 'ml-from-scratch',
    'version': '0.10',
    'description': 'A deep learning library using only pandas and numpy.',
    'long_description': '# ml-from-scratch\nA project where I code machine learning models using only pandas and numpy.\n',
    'author': 'Dhruva Mambapoor',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
